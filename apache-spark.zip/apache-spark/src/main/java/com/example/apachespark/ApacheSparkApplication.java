package com.example.apachespark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApacheSparkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApacheSparkApplication.class, args);
	}

}
